<?php
error_reporting(E_ALL);
session_start();
echo $action=$_POST['action'];

$employeeCode=$_SESSION['time_emp_code'];
$employeeDept=$_SESSION['time_dept'];
include("../includes/db_config.php");
include("../classes/dailytask.php");
$date = date('Y-m-d');
if($action=="add")
{
	  $objdailytask=new dailytask(); 
       $time= $_POST['hours'].':'.$_POST['mins'];
      $typeoftask= $_POST['typeoftask'];
	  
	  $taskdec=$_POST['description'];
	  $type=$_POST['status'];
	  //$insertQuery="INSERT INTO `tbl_daily_task`(`emp_id`, `date`, `type_of_task`, `task_description`, `time`, `type`,`is_visible`) VALUES ('".$employeeCode."','".$date."','".$typeoftask."','".$taskdec."','".$time."','".$type."',1)" ;
	 // $excecuteQuery=mysql_query($insertQuery);
	  $masterResult=$objdailytask->insertdailytask($employeeCode,$date,$typeoftask,$taskdec,$time,$type); 
	if( $masterResult)
	{
	}
	else{
	}
	
}
	

if($action=="update")
	
{

	$id= $_POST['rowid'];
	             

if($id!='')
  {
    $id= $_POST['rowid'];
	  $objdailytask=new dailytask();
	  $masterResult=$objdailytask->gettaskdetailsbyuser($id); 
	  
 while ($row = mysql_fetch_assoc($masterResult)) {
 $time=$row['time'];
 $hours=substr($time, 0, 2);
  $mins= substr($time, -2);
?>
<div class="row">
<?php	if(isset($_POST['update']))
  {
       $id=$_POST['id'];
	  $time= $_POST['hours'].':'.$_POST['mins'];
      $typeoftask= $_POST['typeoftask'];
	  
	  $taskdec=$_POST['description'];
	  $type=$_POST['status'];
	  $objdailytask1=new dailytask();
	 echo $masterResult1=$objdailytask1->updatetaskdetails($employeeCode,$typeoftask,$taskdec,$time,$type,$id); 
	 
		  //echo '<script>window.location="index.php"</script>';
	  
  }
	 ?>
<form class="form-inline" role="form" method="POST">
  <div class="form-group">
    <input type="text" class="form-control" name="typeoftask" id="typeoftask" placeholder="Type of Task" required="" value="<?php echo $row['type_of_task'];?>">
  </div>
  <div class="form-group">   
    <input type="text" class="form-control" name="description" id="description" placeholder="Description" required="" value="<?php echo $row['task_description'];?>">
  </div>
 <div class="form-group">
     <select class="form-control" id="hours" name="hours">
		<?php for($i = 0; $i < 12; $i++): ?>
           <option value="<?php if($i>=10): echo $i; else: echo '0'.$i; endif;?>" <?php if($hours==$i): echo 'selected="selected"'; endif; ?>><?php if($i>=10): echo $i; else: echo '0'.$i; endif;?></option>
        <?php endfor; ?>
       
    </select>
	</div>
	<div class="form-group">
     <select class="form-control" id="mins" name="mins">
		<?php for($i = 0; $i < 59; $i++): ?>
           <option value="<?php if($i>=10): echo $i; else: echo '0'.$i; endif;?>" <?php if($mins==$i): echo 'selected="selected"'; endif; ?>><?php if($i>=10): echo $i; else: echo '0'.$i; endif;?></option>
        <?php endfor; ?>
       
    </select>
   </div>
  <div class="form-group">
    <select class="form-control" id="status" name="status">
      <option value="1" <?php if($row['type']=="1"): echo 'selected="selected"'; endif; ?>>Completed</option>
      <option value="0" <?php if($row['type']=="0"): echo 'selected="selected"'; endif;?>>Pending</option>    
    </select>
  </div>
	<div class="form-group">
		<input type='submit' name='update' value='update' />
		<input type="hidden" name="id" value="<?php echo $row['id'];?>"/>
	</div>
	</form>
	</div>
	<?php 
 } 

}
}

?>